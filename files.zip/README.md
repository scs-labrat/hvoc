# veilid-irc

**Multi-user IRC-style chat over the Veilid P2P network.**

No servers. No accounts. No metadata. Just encrypted peer-to-peer chat with classic IRC semantics.

Built with [Textual](https://textual.textualize.io/) — works natively on **Windows, Linux, and macOS** with mouse support, Rich text, and 16.7M colors.

```
┌──────────┬──────────────────────────────┬──────────┐
│ CHANNELS │  #general — Welcome!         │  USERS   │
│          ├──────────────────────────────┤          │
│ #general │ 14:23 --> alice has joined   │ @alice   │
│ #crypto  │ 14:23 <alice> hey everyone   │ bob      │
│          │ 14:24 <bob> sup!             │ charlie  │
│          │ 14:24 * charlie waves        │          │
│          │ 14:25 -alice- check your DMs │          │
├──────────┴──────────────────────────────┴──────────┤
│ [#general] > _                                     │
└────────────────────────────────────────────────────┘
```

## Quick Start

```bash
pip install veilid textual
python irc_main.py --nick alice --create general --topic "Welcome!"
# Share the CHAN: string with friends
python irc_main.py --nick bob --join "CHAN:eyJrIjoi..."
```

### With a Directory (short join codes)

```bash
# Alice creates a channel and a directory
python irc_main.py --nick alice --create general
#   /dir create              → gives you a DIR:xxxx share string
#   /publish Welcome!        → publishes #general, gives you code like A7K2

# Share the DIR: string with your community (one-time)
# Bob joins the directory and browses channels
python irc_main.py --nick bob --dir "DIR:eyJrIjoi..."
#   /rooms                   → lists all published channels
#   /join A7K2               → joins by 4-char code
#   /join #general           → or by channel name
```

## How It Works

Each channel is a **Veilid DHT record** with a shared-owner keypair:

```
Channel DHT Record (DHTSchema.dflt(32)):
  Subkey 0   : Metadata {name, topic, modes, ops, bans}
  Subkeys 1-31: Member slots {nick, route_blob, pk, ts, away}

Messages: zlib-compressed JSON via app_message fan-out
  alice ──app_message──> bob
       ──app_message──> charlie
```

- **No central server** — channels live on the distributed hash table
- **E2E encrypted** — messages travel via Veilid private routes
- **Heartbeat presence** — stale members pruned after 90s

### Channel Directory

The directory is a **separate shared-owner DHT record** (64 subkeys) that acts as a community channel listing — same pattern as the ASCII webcam app:

```
Directory DHT Record:
  Subkey 0   : Header {name, type, created}
  Subkeys 1-63: Channel entries
    {nick, name, topic, share, short:"A7K2", members, ts}
```

- Anyone with the `DIR:` share string can browse and publish channels
- Each channel gets a deterministic **4-character join code** (SHA256 → base32)
- Stale entries (>24h) are automatically reclaimed
- `/join A7K2` resolves the code → CHAN: share string → joins the channel

## Full IRC Command Reference

### I. Connection & Setup

| Command | Description |
|---------|-------------|
| `/server [host] [port]` | Show/reconnect to veilid-server |
| `/quit [message]` | Disconnect with optional exit message |
| `/nick <name>` | Change your nickname |
| `/user` | Show your identity info |
| `/ping <nick>` | Measure round-trip time to user |

### II. Channel Operations

| Command | Description |
|---------|-------------|
| `/create <name> [topic]` | Create a new channel (Veilid-specific) |
| `/join <CHAN:\|code\|#name>` | Join by share string, 4-char code, or name |
| `/part [#ch] [message]` | Leave a channel with optional message |
| `/topic [#ch] [text]` | View or set channel topic |
| `/invite <nick> [#ch]` | Invite a user (sends share string) |
| `/kick [#ch] <nick> [reason]` | Kick a user (requires op) |
| `/ban [#ch] <pattern>` | Ban a nick/pattern (requires op) |
| `/unban [#ch] <pattern>` | Remove a ban |
| `/kickban [#ch] <nick> [reason]` | Kick + ban in one command |
| `/mode <#ch> <+/-modes>` | Set channel modes (n,t,m,s,p,i) |
| `/mode <#ch> +o <nick>` | Grant operator status |
| `/mode <#ch> +v <nick>` | Grant voice |

### III. Private Communication

| Command | Description |
|---------|-------------|
| `/msg <nick> <text>` | Private message |
| `/query <nick> [text]` | Open private conversation |
| `/notice <target> <text>` | Send a notice (no auto-reply) |
| `/me <action>` | Action emote (* nick does something) |
| `/ignore [nick]` | Toggle ignore for a user (or show list) |

### IV. Information & Status

| Command | Description |
|---------|-------------|
| `/who [#channel]` | List users with details |
| `/whois <nick>` | Detailed user info |
| `/whowas <nick>` | *(N/A in P2P — no server history)* |
| `/list` | List all joined channels |
| `/names [#channel]` | List nicknames |
| `/away [message]` | Set/clear away status |
| `/userhost <nick>` | *(N/A — no hostnames in P2P)* |
| `/time` | Show local time |
| `/version` | Show version info |
| `/admin` | *(N/A — no server admin)* |
| `/info` | Show connection info |
| `/motd` | Message of the day |
| `/stats` | Session statistics |

### V. Network Operator Commands

`/kill`, `/kline`, `/gline`, `/shun`, `/oper` — Not applicable in P2P. Use `/kick`, `/ban`, and `/mode` for channel-level moderation.

### VI. Veilid-Specific

| Command | Description |
|---------|-------------|
| `/share [#channel]` | Show CHAN: invite string |
| `/switch <#channel>` | Switch active channel |
| `/clear` | Clear chat history |
| `/help` | Show all commands |

### VII. Directory (Short Join Codes)

| Command | Description |
|---------|-------------|
| `/dir` | Show directory status |
| `/dir create` | Create a new channel directory |
| `/dir join <DIR:…>` | Join an existing directory |
| `/dir share` | Show directory share string |
| `/rooms` | List all channels in directory |
| `/publish [topic]` | Publish current channel → get 4-char code |
| `/unpublish` | Remove current channel from directory |
| `/join <CODE>` | Join by 4-char directory code |
| `/join #name` | Join by channel name (from directory) |

### Keyboard Shortcuts

| Key | Action |
|-----|--------|
| Ctrl+N | Next channel |
| Ctrl+P | Previous channel |
| Ctrl+Q | Quit |
| Click | Select channel / scroll |

## Channel Modes

| Mode | Description |
|------|-------------|
| `+n` | No external messages (default) |
| `+t` | Only ops can change topic (default) |
| `+m` | Moderated — only voiced/ops can talk |
| `+s` | Secret — hidden from /list |
| `+p` | Private |
| `+i` | Invite-only |

## Installing veilid-server

```bash
# Debian/Ubuntu
sudo apt install veilid-server

# Build from source
git clone https://gitlab.com/veilid/veilid.git
cd veilid && cargo build --release -p veilid-server
```

## File Structure

```
veilid-irc/
├── irc_main.py        # Entry point + full IRC command dispatcher
├── irc_ui.py          # Textual TUI (cross-platform, no curses)
├── irc_channel.py     # Channel management (DHT, modes, bans, kick)
├── irc_directory.py   # Channel directory (short codes, publish/browse)
├── irc_net.py         # Veilid connection (routing context lifecycle)
├── identity.py        # Persistent user identity (optional)
├── bootstrap.py       # Auto-detect/start veilid-server
└── requirements.txt
```

## Security

- Messages are **ephemeral** (RAM only, no logs to disk)
- Transport via Veilid safety routes (sender privacy)
- Channel access gated by shared keypair (treat CHAN: strings like invite links)
- DHT member slots expose nick + opaque route blob (no IP addresses)
- zlib compression before encryption reduces metadata leakage

## License

MPL-2.0 (matching Veilid)
