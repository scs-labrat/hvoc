"""Veilid P2P networking layer for IRC-style multi-user chat.

Handles:
  - Connection to local veilid-server daemon (localhost:5959)
  - Private route creation for receiving messages
  - Incoming app_message decompression and dispatch to ChannelManager
  - Proper routing context lifecycle:
      new_routing_context() → base_rc  (must release)
      base_rc.with_default_safety() → rc  (must release)
    Both are stored and explicitly released on shutdown.
"""

import asyncio
import json
import zlib

import veilid

from irc_channel import ChannelManager


class IRCNet:
    """Manages the Veilid connection and bridges to ChannelManager."""

    def __init__(self):
        self.api = None
        self._rc_base = None   # from new_routing_context()  — MUST release
        self.rc = None         # from with_default_safety()   — MUST release
        self.my_route = None
        self.channel_mgr: ChannelManager | None = None
        self.directory = None  # IRCDirectory (optional)
        self.running = False

        # External callbacks
        self.on_status = None       # (text) -> None
        self.on_message = None      # (channel, msg_dict) -> None

        self._msg_queue: asyncio.Queue = asyncio.Queue()
        self._tasks: list[asyncio.Task] = []

    # ------------------------------------------------------------------
    # Veilid update callback
    # ------------------------------------------------------------------
    async def _update_callback(self, update: veilid.VeilidUpdate):
        if update.kind == veilid.VeilidUpdateKind.APP_MESSAGE:
            await self._msg_queue.put(update.detail.message)

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------
    async def start(self, nick: str, profile_key=None):
        """Connect to veilid-server and initialize ChannelManager."""
        self.running = True
        self._notify("Connecting to veilid-server...")

        self.api = await veilid.json_api_connect(
            "localhost", 5959, self._update_callback
        )

        # ── Routing context: create base, then wrap with safety ──
        # CRITICAL: both objects have a server-side handle that must
        # be released via .release() before the object is GC'd,
        # otherwise veilid-python raises AssertionError in __del__.
        self._rc_base = await self.api.new_routing_context()
        self.rc = await self._rc_base.with_default_safety()

        # Create our private route for receiving messages
        self.my_route = await self.api.new_private_route()

        # Initialize channel manager
        self.channel_mgr = ChannelManager(
            api=self.api,
            rc=self.rc,
            my_route=self.my_route,
            nick=nick,
            profile_key=profile_key,
        )
        self.channel_mgr.on_status = self.on_status
        self.channel_mgr.on_message = self.on_message

        # Start receive loop
        self._tasks.append(asyncio.create_task(self._receive_loop()))

        self._notify("Connected to Veilid network")

    async def stop(self):
        """Graceful shutdown — release ALL Veilid resources in order."""
        self.running = False

        # 1. Channel manager (sends quit notices, clears DHT slots)
        if self.channel_mgr:
            try:
                await self.channel_mgr.shutdown()
            except Exception:
                pass
            self.channel_mgr = None

        # 2. Cancel background tasks
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self._tasks.clear()

        # 3. Release private route
        if self.my_route and self.api:
            try:
                await self.api.release_private_route(self.my_route.route_id)
            except Exception:
                pass
            self.my_route = None

        # 4. Release routing contexts — safety-wrapped FIRST, then base
        if self.rc is not None:
            try:
                await self.rc.release()
            except Exception:
                pass
            self.rc = None

        if self._rc_base is not None:
            try:
                await self._rc_base.release()
            except Exception:
                pass
            self._rc_base = None

        # 5. Release API connection last
        if self.api is not None:
            try:
                await self.api.release()
            except Exception:
                pass
            self.api = None

    # ------------------------------------------------------------------
    # Receive loop
    # ------------------------------------------------------------------
    async def _receive_loop(self):
        """Drain incoming app_messages, decompress, and dispatch."""
        while self.running:
            try:
                raw = await asyncio.wait_for(self._msg_queue.get(), timeout=0.1)
                try:
                    msg = json.loads(zlib.decompress(raw).decode())
                except Exception:
                    try:
                        msg = json.loads(raw.decode())
                    except Exception:
                        continue

                if self.channel_mgr:
                    self.channel_mgr.dispatch_message(msg)

            except asyncio.TimeoutError:
                pass
            except asyncio.CancelledError:
                return
            except Exception:
                pass

    # ------------------------------------------------------------------
    def _notify(self, text: str):
        if self.on_status:
            self.on_status(text)
