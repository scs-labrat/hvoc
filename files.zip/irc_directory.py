"""IRC channel directory using a shared-owner-keypair DHT record.

Adapted from the ASCII webcam chat's directory.py pattern.

Directory DHT record (DHTSchema.dflt(64)):
  subkey 0   : {"name": "public", "created": ts, "v": 2}
  subkeys 1-63: channel entries or empty

Each channel entry:
  {
    "nick": "alice",            # who published it
    "name": "#general",         # channel name
    "topic": "Welcome!",        # channel topic
    "share": "CHAN:eyJrIjoi…",  # full share string (includes keypair)
    "short": "A7K2",            # deterministic 4-char join code
    "members": 3,               # approximate member count at publish time
    "ts": 1234567890.0          # last updated
  }

Shared-owner model: the directory creator shares both the DHT key AND
the owner keypair.  Anyone with the keypair can write to any subkey.
The keypair acts as a community write token.

Share string format: DIR:<base64(json({"k": dir_key, "p": dir_keypair}))>

Local persistence via TableDb("veilid_irc_directory", 1):
  Keys: dir_key, dir_keypair
"""

import base64
import hashlib
import json
import time

import veilid


# Characters for 4-char short codes (unambiguous uppercase, no O/0/I/1)
_CODE_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

# How old an entry can be before it's considered stale (24 hours)
STALE_AGE = 86400


def _generate_short_code(key_str: str) -> str:
    """Derive a deterministic 4-char short code from a string."""
    h = hashlib.sha256(key_str.encode()).digest()
    code = []
    for i in range(4):
        code.append(_CODE_CHARS[h[i] % len(_CODE_CHARS)])
    return "".join(code)


class IRCDirectory:
    """Manages a community channel directory on the Veilid DHT."""

    MAX_SLOTS = 63   # subkeys 1-63

    def __init__(self):
        self.dir_key = None          # TypedKey of the directory DHT record
        self.dir_keypair = None      # KeyPair for write access
        self._db = None              # TableDb handle

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    @classmethod
    async def load(cls, api, rc):
        """Load saved directory from TableDb.  Returns IRCDirectory or None."""
        self = cls()
        self._db = await api.open_table_db("veilid_irc_directory", 1)

        raw_key = await self._db.load(b"dir_key")
        raw_kp = await self._db.load(b"dir_keypair")

        if raw_key and raw_kp:
            self.dir_key = veilid.TypedKey(raw_key.decode())
            self.dir_keypair = veilid.KeyPair(raw_kp.decode())
            try:
                await rc.open_dht_record(self.dir_key, writer=self.dir_keypair)
            except Exception:
                return None
            return self
        return None

    @classmethod
    async def create(cls, api, rc):
        """Create a new directory DHT record."""
        self = cls()
        self._db = await api.open_table_db("veilid_irc_directory", 1)

        schema = veilid.DHTSchema.dflt(64)
        record = await rc.create_dht_record(
            veilid.CryptoKind.CRYPTO_KIND_VLD0, schema
        )
        self.dir_key = record.key
        self.dir_keypair = record.owner_key_pair()

        # Write directory header
        header = {"name": "public", "type": "irc", "created": time.time(), "v": 2}
        await rc.set_dht_value(
            self.dir_key,
            veilid.ValueSubkey(0),
            json.dumps(header).encode(),
        )

        # Persist locally
        await self._db.store(b"dir_key", str(self.dir_key).encode())
        await self._db.store(b"dir_keypair", str(self.dir_keypair).encode())

        return self

    @classmethod
    async def join_from_share(cls, api, rc, share_string: str):
        """Join an existing directory from a DIR: share string."""
        self = cls()
        self._db = await api.open_table_db("veilid_irc_directory", 1)

        payload = share_string
        if payload.upper().startswith("DIR:"):
            payload = payload[4:]

        info = json.loads(base64.b64decode(payload).decode())
        self.dir_key = veilid.TypedKey(info["k"])
        self.dir_keypair = veilid.KeyPair(info["p"])

        await rc.open_dht_record(self.dir_key, writer=self.dir_keypair)

        await self._db.store(b"dir_key", str(self.dir_key).encode())
        await self._db.store(b"dir_keypair", str(self.dir_keypair).encode())

        return self

    def get_share_string(self) -> str:
        """Return the DIR: share string for this directory."""
        info = {"k": str(self.dir_key), "p": str(self.dir_keypair)}
        encoded = base64.b64encode(json.dumps(info).encode()).decode()
        return f"DIR:{encoded}"

    # ------------------------------------------------------------------
    # Publish / unpublish
    # ------------------------------------------------------------------

    async def publish_channel(
        self, rc, nick: str, name: str, topic: str,
        share_string: str, members: int = 0
    ) -> str:
        """Publish a channel to the directory.  Returns the 4-char short code.

        If the channel is already published, update the existing entry.
        """
        short = _generate_short_code(share_string)

        entry = {
            "nick": nick,
            "name": name,
            "topic": topic,
            "share": share_string,
            "short": short,
            "members": members,
            "ts": time.time(),
        }
        data = json.dumps(entry).encode()
        write_opts = veilid.types.SetDHTValueOptions(writer=self.dir_keypair)

        # First pass: look for existing entry for this channel (update in place)
        for subkey in range(1, self.MAX_SLOTS + 1):
            try:
                vd = await rc.get_dht_value(
                    self.dir_key, veilid.ValueSubkey(subkey), True
                )
                if vd is None:
                    continue
                existing = json.loads(vd.data.decode())
                if existing.get("share") == share_string:
                    # Update existing entry
                    await rc.set_dht_value(
                        self.dir_key,
                        veilid.ValueSubkey(subkey),
                        data,
                        options=write_opts,
                    )
                    return short
            except Exception:
                continue

        # Second pass: find an empty or stale slot
        now = time.time()
        for subkey in range(1, self.MAX_SLOTS + 1):
            vd = await rc.get_dht_value(
                self.dir_key, veilid.ValueSubkey(subkey), True
            )

            if vd is None or vd.data == b"" or vd.data == b"{}":
                await rc.set_dht_value(
                    self.dir_key,
                    veilid.ValueSubkey(subkey),
                    data,
                    options=write_opts,
                )
                return short

            try:
                existing = json.loads(vd.data.decode())
                # Empty slot
                if not existing.get("share"):
                    await rc.set_dht_value(
                        self.dir_key,
                        veilid.ValueSubkey(subkey),
                        data,
                        options=write_opts,
                    )
                    return short
                # Stale slot (older than STALE_AGE)
                if now - existing.get("ts", 0) > STALE_AGE:
                    await rc.set_dht_value(
                        self.dir_key,
                        veilid.ValueSubkey(subkey),
                        data,
                        options=write_opts,
                    )
                    return short
            except (json.JSONDecodeError, UnicodeDecodeError):
                # Corrupted slot
                await rc.set_dht_value(
                    self.dir_key,
                    veilid.ValueSubkey(subkey),
                    data,
                    options=write_opts,
                )
                return short

        raise RuntimeError(f"Directory full (all {self.MAX_SLOTS} slots occupied)")

    async def unpublish_channel(self, rc, share_string: str):
        """Remove a channel from the directory."""
        write_opts = veilid.types.SetDHTValueOptions(writer=self.dir_keypair)
        for subkey in range(1, self.MAX_SLOTS + 1):
            try:
                vd = await rc.get_dht_value(
                    self.dir_key, veilid.ValueSubkey(subkey), True
                )
                if vd is None:
                    continue
                existing = json.loads(vd.data.decode())
                if existing.get("share") == share_string:
                    await rc.set_dht_value(
                        self.dir_key,
                        veilid.ValueSubkey(subkey),
                        json.dumps({"share": None}).encode(),
                        options=write_opts,
                    )
                    return True
            except Exception:
                continue
        return False

    # ------------------------------------------------------------------
    # Query
    # ------------------------------------------------------------------

    async def list_channels(self, rc) -> list[dict]:
        """Fetch all active channel entries from the directory."""
        channels = []
        for subkey in range(1, self.MAX_SLOTS + 1):
            try:
                vd = await rc.get_dht_value(
                    self.dir_key, veilid.ValueSubkey(subkey), True
                )
                if vd is None:
                    continue
                entry = json.loads(vd.data.decode())
                if entry.get("share"):
                    channels.append(entry)
            except Exception:
                continue
        return channels

    async def find_by_short_code(self, rc, code: str) -> dict | None:
        """Look up a channel by its 4-char short code."""
        code = code.upper()
        channels = await self.list_channels(rc)
        for entry in channels:
            if entry.get("short", "").upper() == code:
                return entry
        return None

    async def find_by_name(self, rc, name: str) -> dict | None:
        """Look up a channel by name (e.g. #general)."""
        name = name.lower()
        if not name.startswith("#"):
            name = "#" + name
        channels = await self.list_channels(rc)
        for entry in channels:
            if entry.get("name", "").lower() == name:
                return entry
        return None
